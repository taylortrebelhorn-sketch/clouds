import { MolangVariableMap, WeatherType, system, world } from "@minecraft/server";

/*
 * Realism Clouds Fusion
 * ----------------------
 * Cloud-only merge of:
 *   1) Realism+ volumetric cloud emitter (squaredreams_realism:clouds_basic)
 *   2) Realism VFX cloud emitter (spark_vfx:clouds_puffy/soft/stratus)
 *
 * Deliberately omitted from the source addons:
 *   - controller/settings items
 *   - settings menus
 *   - player.json / player entity overrides
 *   - unrelated weather, fog, sound, entity and block systems
 *
 * The two source cloud algorithms remain separate below, so their original
 * density, radius, altitude, movement, texture-selection, wind and timing
 * math continue to coexist in the same script.
 */

const PLUS_PARTICLE = "squaredreams_realism:clouds_basic";
const VFX_PARTICLES = {
  puffy: "spark_vfx:clouds_puffy",
  soft: "spark_vfx:clouds_soft",
  stratus: "spark_vfx:clouds_stratus",
};

// -----------------------------------------------------------------------------
// Shared helpers
// -----------------------------------------------------------------------------
function clamp(value, min, max) {
  return Math.max(min, Math.min(max, value));
}

function randomRange(min, max) {
  return Math.random() * (max - min) + min;
}

function randomRangeInt(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function isLoaded(dimension, location) {
  try {
    return dimension.isChunkLoaded(location);
  } catch {
    // Fallback for older server builds where this method is unavailable.
    return true;
  }
}

function isDesert(dimension, location) {
  try {
    const biome = dimension.getBiome({
      x: Math.floor(location.x),
      y: Math.floor(location.y),
      z: Math.floor(location.z),
    });
    const id = biome?.id ?? String(biome ?? "");
    return /desert/i.test(id);
  } catch {
    return false;
  }
}

function makeVector(x, y, z) {
  return { x, y, z };
}

// -----------------------------------------------------------------------------
// Simplex noise — Realism VFX implementation
// This intentionally keeps the source pack's random-with-replacement
// permutation construction, rather than using the Plus implementation.
// -----------------------------------------------------------------------------
class VfxSimplexNoise {
  constructor() {
    this.grad3 = [
      [1, 1, 0], [-1, 1, 0], [1, -1, 0], [-1, -1, 0],
      [1, 0, 1], [-1, 0, 1], [1, 0, -1], [-1, 0, -1],
      [0, 1, 1], [0, -1, 1], [0, 1, -1], [0, -1, -1],
    ];
    this.p = [];
    for (let i = 0; i < 256; i++) {
      this.p[i] = Math.floor(Math.random() * 256);
    }
    this.perm = [];
    for (let i = 0; i < 512; i++) {
      this.perm[i] = this.p[i & 255];
    }
  }

  dot(g, x, y) {
    return g[0] * x + g[1] * y;
  }

  dot3(g, x, y, z) {
    return g[0] * x + g[1] * y + g[2] * z;
  }

  noise(xin, yin) {
    let n0, n1, n2;
    const F2 = 0.5 * (Math.sqrt(3.0) - 1.0);
    const s = (xin + yin) * F2;
    const i = Math.floor(xin + s);
    const j = Math.floor(yin + s);
    const G2 = (3.0 - Math.sqrt(3.0)) / 6.0;
    const t = (i + j) * G2;
    const X0 = i - t;
    const Y0 = j - t;
    const x0 = xin - X0;
    const y0 = yin - Y0;

    let i1, j1;
    if (x0 > y0) {
      i1 = 1;
      j1 = 0;
    } else {
      i1 = 0;
      j1 = 1;
    }

    const x1 = x0 - i1 + G2;
    const y1 = y0 - j1 + G2;
    const x2 = x0 - 1.0 + 2.0 * G2;
    const y2 = y0 - 1.0 + 2.0 * G2;

    const ii = i & 255;
    const jj = j & 255;
    const gi0 = this.perm[ii + this.perm[jj]] % 12;
    const gi1 = this.perm[ii + i1 + this.perm[jj + j1]] % 12;
    const gi2 = this.perm[ii + 1 + this.perm[jj + 1]] % 12;

    let t0 = 0.5 - x0 * x0 - y0 * y0;
    if (t0 < 0) {
      n0 = 0.0;
    } else {
      t0 *= t0;
      n0 = t0 * t0 * this.dot(this.grad3[gi0], x0, y0);
    }

    let t1 = 0.5 - x1 * x1 - y1 * y1;
    if (t1 < 0) {
      n1 = 0.0;
    } else {
      t1 *= t1;
      n1 = t1 * t1 * this.dot(this.grad3[gi1], x1, y1);
    }

    let t2 = 0.5 - x2 * x2 - y2 * y2;
    if (t2 < 0) {
      n2 = 0.0;
    } else {
      t2 *= t2;
      n2 = t2 * t2 * this.dot(this.grad3[gi2], x2, y2);
    }

    return 70.0 * (n0 + n1 + n2);
  }

  noise3d(xin, yin, zin) {
    let n0, n1, n2, n3;
    const F3 = 1.0 / 3.0;
    const s = (xin + yin + zin) * F3;
    const i = Math.floor(xin + s);
    const j = Math.floor(yin + s);
    const k = Math.floor(zin + s);
    const G3 = 1.0 / 6.0;
    const t = (i + j + k) * G3;
    const X0 = i - t;
    const Y0 = j - t;
    const Z0 = k - t;
    const x0 = xin - X0;
    const y0 = yin - Y0;
    const z0 = zin - Z0;

    let i1, j1, k1, i2, j2, k2;
    if (x0 >= y0) {
      if (y0 >= z0) {
        i1 = 1; j1 = 0; k1 = 0;
        i2 = 1; j2 = 1; k2 = 0;
      } else if (x0 >= z0) {
        i1 = 1; j1 = 0; k1 = 0;
        i2 = 1; j2 = 0; k2 = 1;
      } else {
        i1 = 0; j1 = 0; k1 = 1;
        i2 = 1; j2 = 0; k2 = 1;
      }
    } else {
      if (y0 < z0) {
        i1 = 0; j1 = 0; k1 = 1;
        i2 = 0; j2 = 1; k2 = 1;
      } else if (x0 < z0) {
        i1 = 0; j1 = 1; k1 = 0;
        i2 = 0; j2 = 1; k2 = 1;
      } else {
        i1 = 0; j1 = 1; k1 = 0;
        i2 = 1; j2 = 1; k2 = 0;
      }
    }

    const x1 = x0 - i1 + G3;
    const y1 = y0 - j1 + G3;
    const z1 = z0 - k1 + G3;
    const x2 = x0 - i2 + 2.0 * G3;
    const y2 = y0 - j2 + 2.0 * G3;
    const z2 = z0 - k2 + 2.0 * G3;
    const x3 = x0 - 1.0 + 3.0 * G3;
    const y3 = y0 - 1.0 + 3.0 * G3;
    const z3 = z0 - 1.0 + 3.0 * G3;

    const ii = i & 255;
    const jj = j & 255;
    const kk = k & 255;
    const gi0 = this.perm[ii + this.perm[jj + this.perm[kk]]] % 12;
    const gi1 = this.perm[ii + i1 + this.perm[jj + j1 + this.perm[kk + k1]]] % 12;
    const gi2 = this.perm[ii + i2 + this.perm[jj + j2 + this.perm[kk + k2]]] % 12;
    const gi3 = this.perm[ii + 1 + this.perm[jj + 1 + this.perm[kk + 1]]] % 12;

    let t0 = 0.6 - x0 * x0 - y0 * y0 - z0 * z0;
    if (t0 < 0) {
      n0 = 0.0;
    } else {
      t0 *= t0;
      n0 = t0 * t0 * this.dot3(this.grad3[gi0], x0, y0, z0);
    }

    let t1 = 0.6 - x1 * x1 - y1 * y1 - z1 * z1;
    if (t1 < 0) {
      n1 = 0.0;
    } else {
      t1 *= t1;
      n1 = t1 * t1 * this.dot3(this.grad3[gi1], x1, y1, z1);
    }

    let t2 = 0.6 - x2 * x2 - y2 * y2 - z2 * z2;
    if (t2 < 0) {
      n2 = 0.0;
    } else {
      t2 *= t2;
      n2 = t2 * t2 * this.dot3(this.grad3[gi2], x2, y2, z2);
    }

    let t3 = 0.6 - x3 * x3 - y3 * y3 - z3 * z3;
    if (t3 < 0) {
      n3 = 0.0;
    } else {
      t3 *= t3;
      n3 = t3 * t3 * this.dot3(this.grad3[gi3], x3, y3, z3);
    }

    return 32.0 * (n0 + n1 + n2 + n3);
  }
}

// -----------------------------------------------------------------------------
// Simplex noise — Realism+ implementation
// This keeps the source helper's proper Fisher-Yates permutation construction.
// -----------------------------------------------------------------------------
class PlusSimplexNoise {
  constructor(rng = Math.random) {
    this.grad3 = [
      [1, 1, 0], [-1, 1, 0], [1, -1, 0], [-1, -1, 0],
      [1, 0, 1], [-1, 0, 1], [1, 0, -1], [-1, 0, -1],
      [0, 1, 1], [0, -1, 1], [0, 1, -1], [0, -1, -1],
    ];

    const perm = new Uint8Array(512);
    const permMod12 = new Uint8Array(512);
    const source = new Uint8Array(256);

    for (let i = 0; i < 256; i++) source[i] = i;

    // Exact source shuffle construction: i runs 0..254 and the final
    // unselected value is assigned at index 255.
    for (let i = 0; i < 255; i++) {
      const j = i + Math.floor(rng() * (256 - i));
      const value = source[j];
      source[j] = source[i];
      perm[i] = perm[i + 256] = value;
      permMod12[i] = permMod12[i + 256] = value % 12;
    }

    const last = source[255];
    perm[255] = perm[511] = last;
    permMod12[255] = permMod12[511] = last % 12;

    this.perm = perm;
    this.permMod12 = permMod12;
  }

  noise2D(xin, yin) {
    let n0 = 0, n1 = 0, n2 = 0;
    const F2 = 0.5 * (Math.sqrt(3.0) - 1.0);
    const s = (xin + yin) * F2;
    const i = Math.floor(xin + s);
    const j = Math.floor(yin + s);
    const G2 = (3.0 - Math.sqrt(3.0)) / 6.0;
    const t = (i + j) * G2;
    const X0 = i - t;
    const Y0 = j - t;
    const x0 = xin - X0;
    const y0 = yin - Y0;
    const i1 = x0 > y0 ? 1 : 0;
    const j1 = x0 > y0 ? 0 : 1;
    const x1 = x0 - i1 + G2;
    const y1 = y0 - j1 + G2;
    const x2 = x0 - 1.0 + 2.0 * G2;
    const y2 = y0 - 1.0 + 2.0 * G2;

    const ii = i & 255;
    const jj = j & 255;
    const gi0 = this.permMod12[ii + this.perm[jj]] * 3;
    const gi1 = this.permMod12[ii + i1 + this.perm[jj + j1]] * 3;
    const gi2 = this.permMod12[ii + 1 + this.perm[jj + 1]] * 3;

    let t0 = 0.5 - x0 * x0 - y0 * y0;
    if (t0 >= 0) {
      const g = this.grad3[Math.floor(gi0 / 3)];
      t0 *= t0;
      n0 = t0 * t0 * (g[0] * x0 + g[1] * y0);
    }
    let t1 = 0.5 - x1 * x1 - y1 * y1;
    if (t1 >= 0) {
      const g = this.grad3[Math.floor(gi1 / 3)];
      t1 *= t1;
      n1 = t1 * t1 * (g[0] * x1 + g[1] * y1);
    }
    let t2 = 0.5 - x2 * x2 - y2 * y2;
    if (t2 >= 0) {
      const g = this.grad3[Math.floor(gi2 / 3)];
      t2 *= t2;
      n2 = t2 * t2 * (g[0] * x2 + g[1] * y2);
    }

    return 70.0 * (n0 + n1 + n2);
  }
}

// -----------------------------------------------------------------------------
// Realism VFX wind state used by its cloud emitter.
// The complete wind-state math needed by the cloud system is retained here;
// other VFX weather/wind features are intentionally not carried over.
// -----------------------------------------------------------------------------
const VFX_WIND_CONFIG = {
  wind_speed_base: 0.7,
  wind_speed_increase_rain: 0.6,
  wind_speed_increase_thunder: 1.1,
  global_intensity_range: [0.1, 2],
  global_intensity_time_scale: 700,
  local_intensity_factor: 1.5,
  local_intensity_variation: 0.5,
  local_intensity_noise_scale: 90,
  local_intensity_time_scale: 1600,
  altitude_boost_base: 80,
  altitude_boost_scale: 100,
  direction_change_small: 0.1,
  direction_change_big: 0.4,
  direction_change_big_chance: 0.03,
  direction_change_moderate: 0.9,
};

const WIND_NOISE = new VfxSimplexNoise();
const WIND_NOISE_LAT = new VfxSimplexNoise();
const VFX_CLOUD_NOISE = new VfxSimplexNoise();
let vfxWeather = WeatherType.Clear;
let windAngle = Math.random() * 360 - 180;
let windDelta = 0;
let windDirection = makeVector(0, 0, 0);
let windIntensity = 0;

function updateVfxWind(timeOfDay, absoluteTime) {
  windIntensity = clamp(
    VFX_WIND_CONFIG.wind_speed_base + WIND_NOISE.noise(timeOfDay / VFX_WIND_CONFIG.global_intensity_time_scale, -400),
    VFX_WIND_CONFIG.global_intensity_range[0],
    VFX_WIND_CONFIG.global_intensity_range[1]
  );

  if (vfxWeather === WeatherType.Rain) windIntensity += VFX_WIND_CONFIG.wind_speed_increase_rain;
  if (vfxWeather === WeatherType.Thunder) windIntensity += VFX_WIND_CONFIG.wind_speed_increase_thunder;

  windDelta += randomRange(-VFX_WIND_CONFIG.direction_change_small, VFX_WIND_CONFIG.direction_change_small);
  if (Math.random() < VFX_WIND_CONFIG.direction_change_big_chance) {
    windDelta += randomRange(-VFX_WIND_CONFIG.direction_change_big, VFX_WIND_CONFIG.direction_change_big);
  }
  if (Math.abs(windDelta) > Math.random()) {
    windDelta *= VFX_WIND_CONFIG.direction_change_moderate;
  }

  windAngle = ((windAngle + windDelta + 180 * 5) % 360) - 180;
  const angle = (windAngle * Math.PI) / 180;
  // Source Vector.rotateY(Vector(0,0,-1), angle)
  windDirection = makeVector(Math.sin(angle), 0, -Math.cos(angle));
}

function getVfxWindIntensity(position, factorGlobalIntensity = true, absoluteTime = world.getAbsoluteTime()) {
  const lat = WIND_NOISE_LAT.noise3d(
    position.x / VFX_WIND_CONFIG.local_intensity_noise_scale,
    absoluteTime / VFX_WIND_CONFIG.local_intensity_time_scale,
    position.z / VFX_WIND_CONFIG.local_intensity_noise_scale
  );
  const localValue = Math.pow(1 + lat * VFX_WIND_CONFIG.local_intensity_variation, 2) * VFX_WIND_CONFIG.local_intensity_factor;
  const altitudeBoost = clamp(
    (position.y - VFX_WIND_CONFIG.altitude_boost_base) / VFX_WIND_CONFIG.altitude_boost_scale,
    0,
    1
  );
  const globalFactor = factorGlobalIntensity ? windIntensity : 1;
  return globalFactor * localValue + altitudeBoost;
}

// -----------------------------------------------------------------------------
// Realism+ volumetric cloud system
// -----------------------------------------------------------------------------
const PLUS_CLOUD_NOISE = new PlusSimplexNoise();
const PLUS_DENSITY_TIME_SCALE = 0.005;
const PLUS_TYPE_TIME_SCALE = 0.00012;

function spawnPlusClouds(players, overworld, absoluteTime) {
  const dayCycle = absoluteTime % 24000;
  const cloudDensityNoise = PLUS_CLOUD_NOISE.noise2D((dayCycle * PLUS_DENSITY_TIME_SCALE) % 1, 300);
  const textureTypeNoise = PLUS_CLOUD_NOISE.noise2D((dayCycle * PLUS_TYPE_TIME_SCALE + 1000) % 1, -500);
  const density = clamp(cloudDensityNoise * 0.6 + 0.4, 0, 1);
  const typeVal = clamp(textureTypeNoise * 0.7 + 0.3, 0, 1);

  let cloudHeight = Math.floor(density * 8 + 4);
  if (dayCycle > 14000) cloudHeight = Math.max(0, cloudHeight - 2);

  const shape = typeVal > 0.6 ? 0.7 : typeVal < 0.2 ? 1.3 : 1;
  const timeShift = (dayCycle / 1200) * 1.5;

  for (const player of players) {
    if (!player?.isValid || player.dimension.id !== overworld.id) continue;
    if (!isLoaded(overworld, player.location)) continue;

    const { x, y, z } = player.location;
    const velocity = player.getVelocity();
    const speed = Math.min(6, Math.sqrt(velocity.x ** 2 + velocity.z ** 2));
    const count = Math.floor(cloudHeight * speed * 0.78);

    for (let i = 0; i < count; i++) {
      let radius = randomRange(30, 100);
      if (shape !== 1) radius *= shape;

      const angle = Math.random() * Math.PI * 2;
      const px = x + Math.cos(angle) * radius;
      const pz = z + Math.sin(angle) * radius;
      const noise = PLUS_CLOUD_NOISE.noise2D(px / 100 + timeShift, pz / 100 + 0.6 * timeShift);

      if (noise > randomRange(-0.1, 0.2)) {
        const variables = new MolangVariableMap();
        variables.setVector3("squaredreams_realism_offset", makeVector(
          px - x,
          160 + noise * 60 - y,
          pz - z
        ));
        variables.setFloat("squaredreams_realism_shape", shape);
        overworld.spawnParticle(PLUS_PARTICLE, player.location, variables);
      }
    }
  }
}

// -----------------------------------------------------------------------------
// Realism VFX cloud system
// -----------------------------------------------------------------------------
let vfxTickCounter = 0;
let vfxSlowTick = 0;
let vfxSunnyScore = 0;

function updateVfxWeatherScore() {
  if (vfxWeather !== WeatherType.Clear) {
    vfxSunnyScore = -10;
  } else {
    vfxSunnyScore += 1;
  }
}

function spawnVfxClouds(overworld, timeOfDay, absoluteTime) {
  // Exact source gates retained, except the source's settings switch and
  // northern-light subsystem are omitted because this is now cloud-only.
  if (vfxSunnyScore <= 266) return;

  for (const player of overworld.getPlayers()) {
    if (!player?.isValid) continue;
    if (player.location.y > 32 && player.location.y < 62 && player.isInWater) continue;
    if (player.location.y < 40 || player.location.y > 300) continue;
    if (isDesert(overworld, player.location)) continue;
    if (!isLoaded(overworld, player.location)) continue;

    const overallDensity = VFX_CLOUD_NOISE.noise(absoluteTime / 8_000, 420);
    const overallType = VFX_CLOUD_NOISE.noise(absoluteTime / 14_000, -420);
    const overallTextureVal = VFX_CLOUD_NOISE.noise(absoluteTime / 10_000, -1420);
    const squish = overallType > 0.3 ? 0.6 : overallType < -0.5 ? 1.2 : 1;
    const baseHeight = 178;
    let minRadius = 32;
    let particleId = VFX_PARTICLES.puffy;

    if (overallTextureVal > 0.5) {
      particleId = VFX_PARTICLES.stratus;
      minRadius = 64;
    } else if (overallTextureVal > 0.2) {
      particleId = VFX_PARTICLES.soft;
    }

    let iterations = Math.round((0.5 + overallDensity) * 3.5);
    if (timeOfDay > 13000) iterations -= 2;

    const velocity = player.getVelocity();
    iterations *= clamp(6 * Math.sqrt(velocity.x ** 2 + velocity.z ** 2), 1, 3);

    const location = player.location;
    for (let i = 0; i < iterations; i++) {
      let radius = (1 - Math.pow(Math.random(), 2)) * 190 + minRadius;
      if (squish < 1) radius *= 2;

      const angle = Math.random() * Math.PI * 2;
      const px = location.x + Math.sin(angle) * radius;
      const pz = location.z + Math.cos(angle) * radius;
      const shift = (absoluteTime / 1000) * 1.4;
      const noiseValue = VFX_CLOUD_NOISE.noise(px / 100 + shift, pz / 100 + 0.4 * shift);

      if (noiseValue > randomRange(-0.3, 0.3)) {
        const variables = new MolangVariableMap();
        variables.setVector3("cloud_offset", makeVector(
          px - location.x,
          baseHeight + noiseValue * 20 - location.y,
          pz - location.z
        ));
        variables.setFloat("squish", squish);
        variables.setVector3("direction", windDirection);
        const speed = 0.8 + getVfxWindIntensity(location, true, absoluteTime) / 3;
        variables.setFloat("speed", speed);
        player.spawnParticle(particleId, location, variables);
      }
    }
  }
}

// -----------------------------------------------------------------------------
// Autonomous game loop. No item, command, controller, or player.json required.
// -----------------------------------------------------------------------------
world.afterEvents.weatherChange.subscribe((event) => {
  vfxWeather = event.newWeather;
});

function tick() {
  const overworld = world.getDimension("overworld");
  const timeOfDay = world.getTimeOfDay();
  const absoluteTime = world.getAbsoluteTime();

  // Maintain the VFX source timing exactly enough for its cloud gate:
  // sunny is updated every 3 source ticks and the cloud emitter checks every 10.
  vfxTickCounter += 1;
  vfxSlowTick += 1;
  if (vfxSlowTick % 3 === 0) {
    updateVfxWeatherScore();
  }
  if (vfxSlowTick === 40) {
    vfxSlowTick = 0;
  }

  // Retain the source VFX wind cadence (every 20 ticks).
  if (vfxTickCounter % 20 === 0) {
    updateVfxWind(timeOfDay, absoluteTime);
  }

  // Realism+ volumetric cloud loop: every 20 ticks.
  if (vfxTickCounter % 20 === 0) {
    try {
      const plusPlayers = overworld.getPlayers({ excludeTags: ["squaredreams_realism:disable"] });
      spawnPlusClouds(plusPlayers, overworld, absoluteTime);
    } catch {
      // A failed particle spawn must not stop the cloud loop.
    }
  }

  // Realism VFX cloud loop: every 10 ticks.
  if (vfxTickCounter % 10 === 0) {
    try {
      spawnVfxClouds(overworld, timeOfDay, absoluteTime);
    } catch {
      // A transient unloaded/invalid location must not stop future cloud ticks.
    }
  }
}

let intervalStarted = false;
function startCloudLoop() {
  if (intervalStarted) return;
  intervalStarted = true;
  system.runInterval(tick, 1);
}

world.afterEvents.worldLoad.subscribe(() => {
  try {
    const overworld = world.getDimension("overworld");
    if (typeof overworld.getWeather === "function") {
      vfxWeather = overworld.getWeather();
    }
  } catch {
    // Weather defaults to clear until the first weather-change event.
  }
  startCloudLoop();
});

// Script entry normally occurs after world loading; this also covers versions
// where the worldLoad callback has already fired before this module subscribes.
startCloudLoop();
